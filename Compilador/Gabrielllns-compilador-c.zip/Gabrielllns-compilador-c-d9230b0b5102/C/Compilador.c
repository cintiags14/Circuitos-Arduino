/* INCLUS�O DAS BIBLIOTECAS */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <stdbool.h>
#include <locale.h>
/* FIM INCLUS�O DAS BIBLIOTECAS */

#define TOTAL_SIMBOLOS 92 // total de s�mbolos permitidos
#define RANGE_SIMBOLOS 127 // total de s�mbolos da tabela ascii
#define TOTAL_RESERVADAS 13 // total palavras reservadas informadas

#include "Tabela_Literais.h" // inclui o arquivo da tabela de literais
#include "Funcoes.h" // inclui o arquivo de fun��es
#include "Tabela_Simbolos.h" // inclui o arquivo da tabela de s�mbolos

main() {
	setlocale(LC_ALL, "PORTUGUESE"); // corre��es das acentua��es
	
	FILE *arq; // inst�ncia da vari�vel FILE
	Tabela *tabela_simbolos; // inst�ncia da vari�vel Tabela
	preencher_tabela_literais(); // preenche o vetor de literais baseado na tabela ascii

	/* OUTRAS DECLARA��ES */
	bool verificador, fim_linha = false, valida_reservada = false, valida_variavel = false, valida_tipo = false;
	char cr, crs_reservada[UCHAR_MAX], crs_variavel[UCHAR_MAX], aux_tipo[UCHAR_MAX], *pont_cr = &cr, aux_tamanho[UCHAR_MAX];
	int num, linha = 0, anterior = 0, cont_parentese = 0, cont_chave = 0, aux_linha = 0, cont_caracter = 0, *pont_linha = &linha;
	int i = 0, c = 0, aux_ant = 0, l = 0, aux_num = 0, tipo = 0, aux_atribuicao = 1, *pont_num = &num;
	/* FIM OUTRAS DECLARA��ES */

	arq = fopen("Arquivo_Teste.c", "r"); // tenta abrir o arquivo para leitura

	if(arq == NULL) { // se o arquivo N�O existir...
		printf("Erro ao abrir o arquivo!!");
		exit(0);
	}else{ // se o arquivo existir...
		tabela_simbolos = criar(); // cria a tabela de s�mbolos
		zerar_vetor_auxiliar(aux_tipo); // zera todo o vetor auxiliar
		zerar_vetor_auxiliar(aux_tamanho); // zera todo o vetor auxiliar
		zerar_vetor_auxiliar(crs_variavel); // zera todo o vetor auxiliar
		zerar_vetor_auxiliar(crs_reservada); // zera todo o vetor auxiliar

		while((cr = fgetc(arq)) != EOF) { // recebe o caracter vinda do arquivo .cpp
			num = (int)cr; // converte a STRING em INTEIRO

			if(num != 9) { // desconsidera o Horizontal Tab
				if(num == 10) {  // se VL for igual a QUEBRA DE LINHA acrescente +1 ao n�mero de linhas
					linha++; // incrementa +1 no contador de linhas
				}else{ // fim IF (num == 10)
					anterior = num; // anterior recebe o numero atual
				} // fim else/if (num == 10)

				verificador = validar_literais(num); // valida se o caracter existe na tabela de s�mbolos

				if(verificador == true) { // valida se existe deve se verificar ; ou {
					if(num == 10) { // valida se o caracter � igual a 10				
						if((anterior == 59) || (anterior == 123) || (anterior == 125)) {
							if(num == 123) { // if de valida��o das abertura de chaves
								cont_chave++; // incrementa o contador de chaves
								fim_linha = false; // valida a necessidade de um ponto e virgula
							}else if(num == 59) { // fim else-if de valida��o das chaves
								fim_linha = true; // valida a necessidade de um ponto e virgula
							}else if(num == 125) { // else-if de valida��o do fechamento de chave
								cont_chave--; // decrementa o contador de chaves
								fim_linha = false; // valida a necessidade de um ponto e virgula
							}else{ // fim else/if (num == 125)
								fim_linha = false; // valida a necessidade de um ponto e virgula
							} // fim else/if (num == 123)
						}else{ // fim else (anterior == 59) || (anterior == 123) || (anterior == 125)
							printf("%i - %i \n", anterior, num);
							imprime_erro(2, linha, 'null', 'null'); // chama a fun��o de impress�o de erros
						} // fim else/if (anterior == 59) || (anterior == 123) || (anterior == 125)
					}else{ // fim else/if (num == 10)
						if(num == 123) { // if de valida��o das abertura de chaves
							cont_chave++; // incrementa o contador de chaves
							fim_linha = false; // valida a necessidade de um ponto e virgula
						}else if(num == 59) { // fim else-if de valida��o das chaves
							fim_linha = true; // valida a necessidade de um ponto e virgula
						}else if(num == 125) { // else-if de valida��o do fechamento de chave
							cont_chave--; // decrementa o contador de chaves
							fim_linha = false; // valida a necessidade de um ponto e virgula
						}else{ // fim else/if (num == 125)
							fim_linha = false; // valida a necessidade de um ponto e virgula
						} // fim else/if (num == 123)
					} // fim if/else num == 10

					if(num == 40) { // if de valida��o da abertura de par�nteses
						cont_parentese++; // incrementa +1 ao contador
						aux_linha = linha; // armazena o numero da linha no auxiliar
					} // fim if de valida��o da abertura de par�nteses

					validar_variavel:
					if((cont_parentese > 0)) { // if de valida��o do fechamento de par�nteses
						if((num == 41) && (aux_linha == linha)) { // valida se a linha � a mesma da abertura do par�ntese
							cont_parentese--; // decrementa -1 ao contador
							aux_linha = 0; // zera o valor da linha no auxiliar
						}else if(aux_linha != linha) { // fim if (num == 41) && (aux_linha == linha)
							imprime_erro(5, linha, 'null', 'null'); // chama a fun��o de impress�o de erros
						} // fim else/if (aux_linha != linha)
					}else{ // fim if (cont_parentese > 0)
						if(num == 41) { // valida se a linha � a mesma da abertura do par�ntese
							imprime_erro(6, linha, 'null', 'null'); // chama a fun��o de impress�o de erros
						} // fim if (num == 41)
					} // fim if/else (cont_parentese > 0)

					if((num != 59)) { // valida se NUM � diferente de ;
						if((num != 10) && (num != 32) && (num != 40) && (num != 41) && (num != 123) && (num != 125)) { // se for diferente de \n ESPA�O ( ) { e }
							crs_reservada[i] = (char)num; // armazena o caractere no vetor auxiliar
							i++; // incrementa a vari�vel auxiliar		
						}else if(i > 0) { // se o auxiliar I for maior que zero

							if(((int)crs_reservada[0] == 38) || ((int)crs_reservada[0] == 61)) { // se a primeira posi��o for um '&' ou '='
								valida_variavel = true; // ent�o, n�o � uma palavra reservada
							}else if(((int)crs_reservada[0] >= 48) && ((int)crs_reservada[0] <= 57)) { // fim ELSE/IF ((int)crs_reservada[0] == 38) || ((int)crs_reservada[0] == 61)
								valida_variavel = true; // ent�o, � uma palavra reservada
							}else{ // fim ELSE/IF ((int)crs_reservada[0] >= 48) && ((int)crs_reservada[0] <= 57)
								valida_variavel = false; // n�o � uma palavra reservada
							} // fim ELSE

							if((valida_variavel == false)) { // valida se � uma poss�vel palavra reservada
								for(l = 0; l < TOTAL_RESERVADAS; l++) { // la�o que percorre o array de reservadas
									if(strcasecmp(crs_reservada, reservadas[l]) == 0) { // compara se existe a palavra no vetor de reservadas
										valida_reservada = true; // verifica se a palavra foi validada
										break; // pausa o la�o de repeti��o
									}else{ // fim if de valida��o das palavras
										valida_reservada = false; // verifica se a palavra foi validada
									} // fim else de valida��o das palavras
								} // fim for
							} // fim IF (valida_variavel == false)

							if((valida_reservada == false) && (valida_variavel == false)) { // se a palavra n�o for validada...
								imprime_erro(3, linha, crs_reservada, 'null'); // chama a fun��o de impress�o de erros
							}else{ // fim IF (valida_reservada == false) && (valida_variavel == false)
								valida_tipo = valida_variavel = valida_reservada = false; // redefine as vari�veis auxiliares

								if((strcmp(crs_reservada, "int") == 0) || (strcmp(crs_reservada, "dec") == 0) || (strcmp(crs_reservada, "char") == 0)) { // valida se � um TIPO de VARI�VEL
									strcpy(aux_tipo, crs_reservada); // copia o texto para uma vari�vel auxilar
									valida_tipo = true; // valida que � um poss�vel TIPO de VARI�VEL
								}else{ // fim else de valida��o de tipo da vari�vel
									valida_tipo = false; // valida que N�O um poss�vel TIPO de VARI�VEL
								} // fim else/if de valida��o de tipo da vari�vel
							} // fim ELSE (valida_reservada == false) && (valida_variavel == false)

							if((valida_tipo == false)) { // valida se a palavra � uma poss�vel vari�vel
								aux_num = (int)crs_reservada[1]; // recebe o inteiro do segundo d�gito do array

								if((int)crs_reservada[0] == 38) { // valida se o primeiro caractere � um &
									if((aux_num <= 97) || (aux_num >= 122)) { imprime_erro(7, linha, crs_reservada, 'null'); } // valida o primeiro d�gito da vari�vel

									reinicia_loop_interno: // marca o reinicio do LOOP de valida��o
									while((cr != EOF) && (num == 32)) {
										cr = fgetc(arq); // recebe um novo caractere
										num = (int)cr; // transforma o novo caractere em INTEIRO

										if((num != 32)) { // se o caractere for diferentne de ESPA�O
											if(num == 61) { // valida se o caractere � um IGUAL
												crs_reservada[i] = (char)num; // armazena o caractere no vetor auxiliar
												i++; // incrementa a vari�vel auxiliar

												receber_novo_numero(arq, pont_num, pont_cr); // recebe um novo caractere

												if(num == 32) { goto reinicia_loop_interno; } // reinicia o LOOP
											}else{ // fim IF (num == 61)
												bool atribuicao = false; // valida se houve alguma possibilidade de atribui��o
												int ultimo_digito = (int)crs_reservada[i-aux_atribuicao];

												if((ultimo_digito != 44) && (ultimo_digito != 61) && (anterior == 32)) {
													imprime_erro(10, linha, 'null', 'null'); // chama a fun��o de impress�o de erros

													i = 0; // redefine a vari�vel auxiliar
													aux_atribuicao = 1; // redefine a vari�vel auxiliar
													zerar_vetor_auxiliar(crs_variavel); // zera todo o vetor auxiliar
												}else if(ultimo_digito == 44) { // se o �ltimo d�gito for v�rgula
													crs_reservada[i-1] = NULL; // zera a pen�ltima casa do array
													tabela_simbolos = insere_fim(tabela_simbolos, aux_tipo, crs_reservada,  "NULL", "NULL", pont_linha); // o valor � inserido na tabela

													i = 0; // redefine a vari�vel auxiliar
													aux_atribuicao = 1; // redefine a vari�vel auxiliar
													zerar_vetor_auxiliar(crs_reservada); // zera todo o vetor auxiliar
												}

												if(ultimo_digito == 61) { aux_atribuicao++; atribuicao = true; } // valida se h� um sinal de igual

												while((num != 10) && (cr != EOF)) { // repeti��o para pegar os valores atribu�dos as vari�veis
													if(num != 44) { // se for diferente de v�rgula
														crs_reservada[i] = (char)num; // armazena o caractere no vetor auxiliar
														i++; // incrementa a vari�vel auxiliar

														anterior = num; // anterior recebe o numero atual
														receber_novo_numero(arq, pont_num, pont_cr); // recebe um novo caractere

														if(num == 32) { goto reinicia_loop_interno; } // reinicia o LOOP
													}else{ // fim IF (num != 44)
														break; // pausa a repeti��o do while
													} // fim IF/ELSE (num != 44)
												} // fim WHILE (num != 59) && (cr != EOF)

												if(num == 44) { // valida se o n�mero � uma v�rgula
													if((anterior <= 48) || (anterior >= 57)) { // valida se a vari�vel 'anterior' � <= 48 ou >= 57
														aux_atribuicao = 1; // redefine a vari�vel auxiliar
														imprime_erro(9, linha, crs_reservada, 'null'); // chama a fun��o de impress�o de erros
													} // fim if (anterior <= 48) || (anterior >= 57)					
												}else if((num == 10) && ((int)crs_reservada[i-aux_atribuicao] == 61)) { // se for quebra de linha e o s�mbolo do �ndice for um igual
													aux_atribuicao = 1; // redefine a vari�vel auxiliar
													imprime_erro(9, linha, crs_reservada, 'null'); // chama a fun��o de impress�o de erros
												} // fim if (num == 10) && ((int)crs_reservada[i-aux_atribuicao] == 61)

												if((anterior != 59) && (num != 44)) { // se o 'anterior' for diferente de ponto e v�rgula e 'num' for igual a v�rgula
													aux_atribuicao = 1; // redefine a vari�vel auxiliar
													imprime_erro(2, linha, 'null', 'null'); // chama a fun��o de impress�o de erros
												} // valida a finaliza��o da lina e chama a fun��o de impress�o de erros

												if((atribuicao == false) && ((num != 44) || (num != 59)) && (anterior != 59)) { // valida se a vari�vel foi declarada corretemente
													aux_atribuicao = 1; // redefine a vari�vel auxiliar
													imprime_erro(9, linha, crs_reservada, 'null'); // chama a fun��o de impress�o de erros
												} // fim IF (atribuicao == false) && ((num != 44) || (num != 59))
												
												receber_novo_numero(arq, pont_num, pont_cr); // recebe um novo caractere

												int nv = 0, corrige = 0, x = 0; // instancia das vari�veis auxiliares
												bool valida_sinal_igual = false; // instancia das vari�veis auxiliares
	
												for(x = 0; x < i; x++) { // repeti��o para pegar o valor atribu�do a vari�vel
													if((int)crs_reservada[x] == 61) { valida_sinal_igual = true; } // valida se h� valor atribu�do

													if((valida_sinal_igual == true) && ((int)crs_reservada[x] != 61) && ((int)crs_reservada[x] != 59)) { // valida se existe valores atribu�dos
														crs_variavel[nv] = crs_reservada[x]; // atribui novo valor para o array auxiliar
														crs_reservada[x] = NULL;  // seta valor NULL para a posi��o X
														nv++; // incrementa a vari�vel auxiliar
													}else if(((int)crs_reservada[x] == 61) || ((int)crs_reservada[x] == 59)) { // se encontrar o caractere IGUAL
														crs_reservada[x] = NULL; // seta valor NULL para a posi��o X
													} // fim ELSE/IF ((int)crs_reservada[x] == 61)
												} // fim FOR

												tabela_simbolos = insere_fim(tabela_simbolos, aux_tipo, crs_reservada, crs_variavel, "NULL", pont_linha); // o valor � inserido na tabela

												i = 0; // redefine a vari�vel auxiliar
												aux_atribuicao = 1; // redefine a vari�vel auxiliar
												zerar_vetor_auxiliar(crs_variavel); // zera todo o vetor auxiliar
												zerar_vetor_auxiliar(crs_reservada); // zera todo o vetor auxiliar
											} // fim ELSE/IF (num == 61)
										} // fim IF (num != 32)
									} // fim WHILE (cr != EOF) && (num == 32)

									if(num == 40) { // se o NUM for uma abertura de par�ntese
										int t = 0; // vari�vel auxiliar

										if((strcmp(aux_tipo, "char") == 0) || (strcmp(aux_tipo, "dec") == 0)) { // valida se o tipo de vari�vel � CHAR ou DEC
											while((cr != EOF) && (num != 41)) { // enquanto n�o achar o fechamento do par�nteses....
												receber_novo_numero(arq, pont_num, pont_cr); // recebe um novo caractere

												if(num != 59) { // valida se encontrou um ponto e v�rgula
													if(num != 44) { // valida se � uma v�rgula
														if((num != 41)) { // valida se o par�nteses foi fechado
															aux_tamanho[t] = (char)num; // armazena o caractere no vetor auxiliar
															t++; // incrementa a vari�vel auxiliar
														}else{ // fim IF (num != 41)
															cont_parentese--; // decrementa a vari�vel auxiliar
															break; // para o la�o de repeti��o
														} // fim ELSE/IF (num != 41)
													}else{ // fim IF (num != 44)
														imprime_erro(11, linha, crs_reservada, 'null'); // chama a fun��o de impress�o de erros
													} // fim ELSE/IF (num != 44)
												}else{ // fim IF (num != 59)
													imprime_erro(5, linha, 'null', 'null'); // chama a fun��o de impress�o de erros
												} // fim ELSE/IF (num != 59)									
											} // fim WHILE

											tabela_simbolos = insere_fim(tabela_simbolos, aux_tipo, crs_reservada, "NULL", aux_tamanho, pont_linha); // o valor � inserido na tabela

											i = 0; // redefine a vari�vel auxiliar
											zerar_vetor_auxiliar(aux_tamanho); // zera todo o vetor auxiliar
											zerar_vetor_auxiliar(crs_reservada); // zera todo o vetor auxiliar
										} // fim IF (strcmp(aux_tipo, "char") == 0) || (strcmp(aux_tipo, "dec") == 0)
									} // fim IF (num == 40)
								}else{ // valida as fun��es de palavras reservadas PUTS e GETS								
									if((strcmp(crs_reservada, "puts") == 0) || (strcmp(crs_reservada, "gets") == 0)) { // valida se a palavra reservada � 'puts' ou 'gets'
										receber_novo_numero(arq, pont_num, pont_cr); // recebe um novo caractere

										i = 0; // redefine a vari�vel auxiliar
										zerar_vetor_auxiliar(crs_reservada); // zera todo o vetor auxiliar

										goto validar_variavel; // reinicia o LOOP
									} // fim IF (strcmp(crs_reservada, "puts") == 0) || (strcmp(crs_reservada, "gets") == 0)
								} // fim ELSE/IF ((int)crs_reservada[0] == 38)
							} // fim IF (valida_tipo == false)

							i = 0; // redefine a vari�vel auxiliar
							zerar_vetor_auxiliar(crs_reservada); // zera todo o vetor auxiliar
						} // fim IF (i > 0)
					} // fim IF (num != 59)
				}else{ // fim else de valida��o de caracteres
					imprime_erro(4, linha, '\0', cr); // chama a fun��o de impress�o de erros
				} // fim IF(verificador == true)
			} // fim IF(num != 9) 
		} // fim WHILE
	} // fim ELSE(arq == NULL)
	
	if(cont_chave != 0) { // valida o total de chaves existentes
		imprime_erro(1, linha, 'null', 'null'); // chama a fun��o de impress�o de erros
	}else{ // fim if de valida��o de cont_chave
		//prime(tabela_simbolos); // imprime a tabela de s�mbolos
	} // fim ELSE/IF (cont_chave != 0)
	
	fclose(arq); // fecha o arquivo 
	
	printf("\n\n");
	system("pause");
}
