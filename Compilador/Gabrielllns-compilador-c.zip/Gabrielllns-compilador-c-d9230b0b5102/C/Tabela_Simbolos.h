typedef struct TabelaSimbolos {
	char tipo[UCHAR_MAX], nome[UCHAR_MAX], valor[UCHAR_MAX], tamanho[UCHAR_MAX];
	struct TabelaSimbolos *prox;		
} Tabela;

Tabela* criar() { // Fun��o de cria��o da Tabela de S�mbolos
	return NULL;   
}

bool busca_inteligente(Tabela* l, char *tipo, char *nome, char *valor) { // Fun��o de busca inteligente
	Tabela *aux = l; // Auxiliar que recebe o �ltimo inserido na tabela de s�mbolos
	
	while(aux != NULL) { // Enquanto AUX for diferente de NULL  
		if((strcmp(aux->tipo, tipo) == 0) && (strcmp(aux->nome, nome) == 0)) { // Verifica se o TIPO e NOME da vari�vel j� existe na tabela, caso exista o valor � alterado
			strcpy(aux->nome, nome);
			strcpy(aux->valor, valor);

			return true; // Retorna verdadeiro
		} // Fim IF

		aux = aux->prox; // Passa para o pr�ximo
	} // Fim WHILE
	
	return false; // Retorna false
}

void imprime(Tabela* l) {
	Tabela* aux = l; 
	
	if(aux == NULL) {
		printf("A tabela esta vazia! \n\n");   
	}else{
		printf("[=================================================================] \n");
		printf("[  \t\t\t TABELA DE S�MBOLOS \t\t\t  ] \n");
		printf("[=================================================================] \n");
		printf("[ \t TIPO \t | \t NOME  \t     |   VALOR   |    TAMANHO \t  ] \n");
		printf("[=================================================================] \n");

		while(aux != NULL) {
			printf("[ \t %s \t | \t %s     | \t    %s \t | \t %s \t  ] \n", aux->tipo, aux->nome, aux->valor, aux->tamanho);
			aux = aux->prox;
		}

		printf("[=================================================================] \n");
	}
}

Tabela* insere_fim(Tabela* l, char *tipo, char *nome, char *valor, char *tamanho, int *linha) {
	Tabela* aux = l;
	bool validar = false;
	Tabela* novo = (Tabela*) malloc(sizeof(Tabela));
	
	strcpy(novo->tipo, tipo);
	strcpy(novo->nome, nome);
	strcpy(novo->valor, valor);
	strcpy(novo->tamanho, tamanho);

	if(aux == NULL) {
		novo->prox = l; 
		return novo; 
	}else{
		validar = busca_inteligente(l, novo->tipo, novo->nome, novo->valor);

		if(validar == true) {
			imprime_erro(8, *linha, novo->nome, 'null'); // chama a fun��o de impress�o de erros 
		}else{
			while(aux->prox != NULL) {
				aux = aux->prox;
			}
			
			aux -> prox = novo;
			novo->prox = NULL;
		}

		return l;
	}
}
