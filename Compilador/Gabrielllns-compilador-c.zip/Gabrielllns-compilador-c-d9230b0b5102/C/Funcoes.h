bool validar_literais(int vl) { // valida se o caractere informado pode ser utilizado
	int i; // vari�vel auxiliar

	for(i = 0; i < TOTAL_SIMBOLOS; i++) { // percorre o array de s�mbolos permitidos
		if(simbolos[i] == vl) { // se o s�mbolo for v�lido
			return true; // retorna TRUE
		} // fim IF
	} // fim FOR
	
	return false; // retorna FALSE caso encontre um s�mbolo inv�lido
} // fim validar_literais

void preencher_tabela_literais() { // preencha o vetor de literais
	int i = 0, c = 0; // vari�veis auxiliares

	while(i < RANGE_SIMBOLOS) { // percorre todos os simbolos permitidos da tabela ascii
		if((i != 64) && (i != 96) && (i != 94) && (i != 126)) { // valida alguns caracteres n�o permitidos
			if((i == 10) || (i >= 32)) {  // SE encontre algum s�mbolo v�lido...
				simbolos[c] = i; // o valor � inserido no array de s�mbolos
				c++; // o array de s�mbolos � incrementado
			} // fim if (i == 10) || (i >= 32)
		} // fim (i != 64) && (i != 96) && (i != 94) && (i != 126)

		i++; // o valor de i � incrementado
	} // fim WHILE
} // fim preencher_tabela_literais

void zerar_vetor_auxiliar(char vetor_auxiliar[]) { // zera todos os �ndices do vetor informado
	int i = 0;

	for(i = 0; i < UCHAR_MAX; i++) { // percorre o array auxiliar
		vetor_auxiliar[i] = '\0'; // atribui vazio aos �ndices do vetor
	} // fim FOR
} // fim zerar_vetor_auxiliar


void imprime_erro(int tipo, int linha, char *palavra, char simbolo) { // imprime os erros e seu tipo
	switch(tipo) {
		case 1: printf("\n\n Erro na linha %i: falta o fechamento da chave! \n\n", linha); break; // fim case 1
		case 2: printf("\n\n Erro na linha %i: falta o ponto e v�rgula para finalizar a linha! \n\n", linha); break; // fim case 2
		case 3: printf("\n\n Erro na linha %i: a palavra %s � inv�lida! \n\n", linha, palavra); break; // fim case 3
		case 4: printf("\n\n Erro na linha %i: o caractere %s � inv�lido! \n\n", linha, simbolo); break; // fim case 4
		case 5: printf("\n\n Erro na linha %i: falta o fechamento de par�ntese! \n\n", linha); break; // fim case 5
		case 6: printf("\n\n Erro na linha %i: falta a abertura de par�ntese! \n\n", linha); break; // fim case 6
		case 7: printf("\n\n Erro na linha %i: a vari�vel %s � inv�lida! \n\n", linha, palavra); break; // fim case 7
		case 8: printf("\n\n Erro na linha %i: a vari�vel %s j� foi declarada! \n\n", linha, palavra); break; // fim case 8
		case 9: printf("\n\n Erro na linha %i: a declara��o da vari�vel %s esta incorreta! \n\n", linha, palavra); break; // fim case 9
		case 10: printf("\n\n Erro na linha %i: falta uma v�rgula! \n\n", linha); break; // fim case 10
		case 11: printf("\n\n Erro na linha %i: o tamanho da vari�vel %s esta incorreto! \n\n", linha, palavra); break; // fim case 11
	} // fim SWITCH
	
	exit(0); // finaliza o programa
} // fim imprime_erro

void receber_novo_numero(FILE *arquivo, int *num, char *cr) { // recebe um novo caractere do arquivo
	*cr = fgetc(arquivo); // recebe um novo caractere
	*num = (int)*cr; // transforma o novo caractere em INTEIRO
} // fim receber_novo_numero
