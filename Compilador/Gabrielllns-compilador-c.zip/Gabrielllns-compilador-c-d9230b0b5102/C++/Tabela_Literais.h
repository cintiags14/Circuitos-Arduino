int simbolos[TOTAL_SIMBOLOS];
char reservadas[TOTAL_RESERVADAS][7] = { "main", "gets", "puts", "if", "then", "else", "int", "char", "dec", "for" };
