package com.unievangelica.progwebback.dominio.funcionario;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FuncionarioService {

    @Autowired
    private FuncionarioRepository funcionarioRepository;


    public Funcionario salvar(Funcionario funcionario) {
        return funcionarioRepository.save(funcionario);
    }

    public boolean excluir(Long funcionarioId) {
        Funcionario funcionarioBusca = funcionarioRepository.getOne(funcionarioId);
        if (funcionarioBusca != null) {
            funcionarioRepository.delete(funcionarioBusca);
            return true;
        } else {
            return false;
        }
    }

    public Funcionario buscarPeloId(Long funcionarioId) {
        return funcionarioRepository.getOne(funcionarioId);
    }

    public List<Funcionario> findAll() {
        return funcionarioRepository.findAll();
    }

}
