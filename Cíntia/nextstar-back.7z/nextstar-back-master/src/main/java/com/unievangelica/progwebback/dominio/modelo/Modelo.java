package com.unievangelica.progwebback.dominio.modelo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.unievangelica.progwebback.dominio.colecao.Colecao;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "modelo")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Modelo implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "modelo_id_seq")
    @SequenceGenerator(name = "modelo_id_seq", sequenceName = "modelo_id_seq", allocationSize = 1)
    @Column(name = "id")
    private long id;

    @Column(name = "codigo")
    private String codigo;

    @NotNull
    @Column(name = "nome_modelo")
    private String nomeModelo;

    @Column(name = "matriz_referencia")
    private String matrizReferencia;

    @Column(name = "enfesto")
    private String enfesto;

    @Column(name = "tipo_modelo")
    private String tipoModelo;

    @Column(name = "data_cadastro")
    private Date dataCadastro = new Date();

    @Column(name = "custo_total")
    private BigDecimal custoTotal;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "colecao_id", nullable = false)
    private Colecao colecao;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNomeModelo() {
        return nomeModelo;
    }

    public void setNomeModelo(String nomeModelo) {
        this.nomeModelo = nomeModelo;
    }

    public String getMatrizReferencia() {
        return matrizReferencia;
    }

    public void setMatrizReferencia(String matrizReferencia) {
        this.matrizReferencia = matrizReferencia;
    }

    public String getEnfesto() {
        return enfesto;
    }

    public void setEnfesto(String enfesto) {
        this.enfesto = enfesto;
    }

    public String getTipoModelo() {
        return tipoModelo;
    }

    public void setTipoModelo(String tipoModelo) {
        this.tipoModelo = tipoModelo;
    }

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public BigDecimal getCustoTotal() {
        return custoTotal;
    }

    public void setCustoTotal(BigDecimal custoTotal) {
        this.custoTotal = custoTotal;
    }

    public Colecao getColecao() {
        return colecao;
    }

    public void setColecao(Colecao colecao) {
        this.colecao = colecao;
    }
}