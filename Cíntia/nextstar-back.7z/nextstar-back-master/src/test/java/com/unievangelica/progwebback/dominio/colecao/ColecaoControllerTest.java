package com.unievangelica.progwebback.dominio.colecao;

import com.unievangelica.progwebback.ProgWebBackApplication;
import io.restassured.module.mockmvc.RestAssuredMockMvc;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.List;

import static io.restassured.module.mockmvc.RestAssuredMockMvc.get;
import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = ProgWebBackApplication.class)
@WebAppConfiguration
@ContextConfiguration
public class ColecaoControllerTest {

    @Mock
    public Colecao colecao;
    @Autowired
    WebApplicationContext webApplicationContext;
    @InjectMocks
    private ColecaoController colecaoController;
    @Mock
    private List<Colecao> colecaoList;

    @Mock
    private ColecaoService colecaoService;

    @Mock
    private ColecaoRepository colecaoRepository;

    private MockMvc mockMvc;

    @Before
    public void init() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webApplicationContext).build();
        RestAssuredMockMvc.mockMvc(this.mockMvc);

        colecao.setId(1);
        colecao.setNomeColecao("Coleção 1");
        colecaoList.add(colecao);
    }

    /**
     * Testa o método findAll.
     */
    @Test
    public void findAll() {
        BDDMockito.given(colecaoRepository.findAll()).willReturn(colecaoList);

        // RestAssuredMockMvc
        List<Colecao> response = get("/colecao")
                .then()
                .statusCode(HttpStatus.OK.value())
                .extract()
                .path("content");

        assertTrue(!response.isEmpty());
    }

}
