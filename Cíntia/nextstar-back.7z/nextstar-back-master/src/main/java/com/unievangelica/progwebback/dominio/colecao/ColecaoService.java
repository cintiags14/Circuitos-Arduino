package com.unievangelica.progwebback.dominio.colecao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ColecaoService {

    @Autowired
    private ColecaoRepository colecaoRepository;


    public Colecao salvar(Colecao colecao) {
        return colecaoRepository.save(colecao);
    }

    public boolean excluir(Long produtoId) {
        Colecao colecaoBusca = colecaoRepository.getOne(produtoId);
        if (colecaoBusca != null) {
            colecaoRepository.delete(colecaoBusca);
            return true;
        } else {
            return false;
        }
    }

    public Colecao buscarPeloId(Long produtoId) {
        return colecaoRepository.getOne(produtoId);
    }

    public List<Colecao> findAll() {
        return colecaoRepository.findAll();
    }
}
