package com.unievangelica.progwebback.dominio.funcionario;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/funcionario")
public class FuncionarioController {

    @Autowired
    private FuncionarioService funcionarioService;

    @PostMapping
    public ResponseEntity<?> save(@Validated @RequestBody Funcionario funcionario) {
        return new ResponseEntity(funcionarioService.salvar(funcionario), HttpStatus.CREATED);
    }

    @PutMapping
    public ResponseEntity<?> alterar(@Validated @RequestBody Funcionario funcionario) {
        return new ResponseEntity(funcionarioService.salvar(funcionario), HttpStatus.OK);
    }

    @DeleteMapping(value = "/{funcionarioId}")
    public ResponseEntity<?> excluir(@PathVariable Long funcionarioId) {
        return new ResponseEntity(funcionarioService.excluir(funcionarioId), HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<?> findAll() {
        return new ResponseEntity(funcionarioService.findAll(), HttpStatus.OK);
    }

    @GetMapping(value = "/{funcionarioId}")
    public ResponseEntity<?> findById(@PathVariable Long funcionarioId) {
        return new ResponseEntity(funcionarioService.buscarPeloId(funcionarioId), HttpStatus.OK);
    }
}
