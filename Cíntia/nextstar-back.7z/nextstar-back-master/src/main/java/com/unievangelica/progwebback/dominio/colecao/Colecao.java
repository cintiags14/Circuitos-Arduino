package com.unievangelica.progwebback.dominio.colecao;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.unievangelica.progwebback.dominio.modelo.Modelo;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "colecao")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler", "modelos"})
public class Colecao implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "colecao_id_seq")
    @SequenceGenerator(name = "colecao_id_seq", sequenceName = "colecao_id_seq", allocationSize = 1)
    @Column(name = "id")
    private long id;

    @NotNull
    @Column(name = "nome_colecao")
    private String nomeColecao;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true, mappedBy = "colecao")
    private List<Modelo> modelos = new ArrayList<>();

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNomeColecao() {
        return nomeColecao;
    }

    public void setNomeColecao(String nomeColecao) {
        this.nomeColecao = nomeColecao;
    }

    public List<Modelo> getModelos() {
        return modelos;
    }

    public void setModelos(List<Modelo> modelos) {
        this.modelos = modelos;
    }

    @Override
    public String toString() {
        return "Noma da coleção: " + nomeColecao;
    }
}