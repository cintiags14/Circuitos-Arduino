package com.unievangelica.progwebback.dominio.modelo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/informacoes-modelo")
public class ModeloController {

    @Autowired
    private ModeloService modeloService;

    @PostMapping
    public ResponseEntity<?> save(@Validated @RequestBody Modelo modelo) {
        return new ResponseEntity(modeloService.salvar(modelo), HttpStatus.CREATED);
    }

    // criar busca modelo por coleção id
    @GetMapping(value = "/colecao/{colecaoId}")
    public ResponseEntity<?> findByColecaoId(@PathVariable Long colecaoId) {
        return new ResponseEntity(modeloService.findByColecaoId(colecaoId), HttpStatus.OK);
    }

//    @PutMapping
//    public ResponseEntity<?> alterar(@Validated @RequestBody Colecao colecao){
//        return new ResponseEntity(colecaoService.salvar(colecao), HttpStatus.OK);
//    }

    @DeleteMapping(value = "/{modeloId}")
    public ResponseEntity<?> excluir(@PathVariable Long produtoId) {
        return new ResponseEntity(modeloService.excluir(produtoId), HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<?> findAll() {
        return new ResponseEntity(modeloService.findAll(), HttpStatus.OK);
    }

    @GetMapping(value = "/{modeloId}")
    public ResponseEntity<?> findById(@PathVariable Long modeloId) {
        return new ResponseEntity(modeloService.findById(modeloId), HttpStatus.OK);
    }


}
