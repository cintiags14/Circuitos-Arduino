package com.unievangelica.progwebback.dominio.colecao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/colecao")
public class ColecaoController {

    @Autowired
    private ColecaoService colecaoService;

    @PostMapping
    public ResponseEntity<?> save(@Validated @RequestBody Colecao colecao) {
        System.out.println(colecao.toString());
        return new ResponseEntity(colecaoService.salvar(colecao), HttpStatus.CREATED);
    }

//    @PutMapping
//    public ResponseEntity<?> alterar(@Validated @RequestBody Colecao colecao){
//        return new ResponseEntity(colecaoService.salvar(colecao), HttpStatus.OK);
//    }

    @DeleteMapping(value = "/{produtoId}")
    public ResponseEntity<?> excluir(@PathVariable Long produtoId) {
        return new ResponseEntity(colecaoService.excluir(produtoId), HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<?> findAll() {
        return new ResponseEntity(colecaoService.findAll(), HttpStatus.OK);
    }

    @GetMapping(value = "/{produtoId}")
    public ResponseEntity<?> findById(@PathVariable Long produtoId) {
        return new ResponseEntity(colecaoService.buscarPeloId(produtoId), HttpStatus.OK);
    }


}
