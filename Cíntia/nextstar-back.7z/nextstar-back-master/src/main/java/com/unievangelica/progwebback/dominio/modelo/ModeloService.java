package com.unievangelica.progwebback.dominio.modelo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ModeloService {

    @Autowired
    private ModeloRepository modeloRepository;


    public Modelo salvar(Modelo modelo) {
        return modeloRepository.save(modelo);
    }

    public boolean excluir(Long produtoId) {
        Modelo colecaoBusca = modeloRepository.getOne(produtoId);
        if (colecaoBusca != null) {
            modeloRepository.delete(colecaoBusca);
            return true;
        } else {
            return false;
        }
    }

    public Modelo modeloRepository(Long modeloId) {
        return modeloRepository.getOne(modeloId);
    }

    public List<Modelo> findAll() {
        return modeloRepository.findAll();
    }

    public Modelo findById(Long modeloId) {
        return modeloRepository.getOne(modeloId);
    }

    public List<Modelo> findByColecaoId(Long colecaoId) {
        return modeloRepository.getByColecaoId(colecaoId);
    }

}
