// desconsidera os simbolos ESPA�O ( ) { } ; \n e &
if((num != 32) && (num != 40) && (num != 41) && (num != 123) && (num != 125) && (num != 10) && (num != 59)) {
	if((num >= 48) || (num <= 57) || (num == 61) || (num == 44)) { // se for diferente de v�rgula
		crs_reservada[i] = (char)num; // armazena o caractere no vetor auxiliar
		i++; // incrementa a vari�vel auxiliar
	}
}else{
	if(i > 0) { // valida se o auxiliar que armazena as vari�veis � maior que VAZIO
		if((valida_tipo == false)) {
			for(l = 0; l < TOTAL_RESERVADAS; l++) {
				if(strcasecmp(crs_reservada, reservadas[l]) == 0) { // compara se existe a palavra no vetor de reservadas
					valida_reservada = true; // verifica se a palavra foi validada
					break; // pausa o la�o de repeti��o
				}else{ // fim if de valida��o das palavras
					valida_reservada = false; // verifica se a palavra foi validada
				} // fim else de valida��o das palavras
			} // fim for
		}else{ // fim else (valida_tipo == false)
			valida_tipo = false; // seta os valores padr�es
			valida_reservada = true; // seta os valores padr�es
		} // fim else/if (valida_tipo == false)

		if(valida_reservada == false) { // se a palavra n�o for validada...
			//imprime_erro(3, linha, crs_reservada); // chama a fun��o de impress�o de erros
		}else{ // se a palavra for validada...
			// valida o array formado � um tipo de vari�vel INT / DEC / CHAR
			if((strcmp(crs_reservada, "int") == 0) || (strcmp(crs_reservada, "dec") == 0) || (strcmp(crs_reservada, "char") == 0)) {
				strcpy(aux_tipo, crs_reservada);
				valida_tipo = true;
			}else{ // fim else de valida��o de tipo da vari�vel
				valida_tipo = false;
			} // fim else/if de valida��o de tipo da vari�vel

			if((valida_tipo == false) && ((int)crs_reservada[0] == 38)) { // valida se a palavra � uma poss�vel vari�vel
				aux_num = (int)crs_reservada[1]; // recebe o inteiro do segundo d�gito do array

				if((aux_num >= 97) && (aux_num <= 122)) { // valida se o segundo d�gito da vari�vel est� em caixa baixa
					aux_num = (int)crs_reservada[i-1]; // recebe o inteiro do �ltimo d�gito do array
					puts(crs_reservada);
					if(aux_num == 40) { // se encontrar uma abertura de parentese
						printf("%i \t", aux_num);
						printf("ok");	
					}else{ // se n�o encontrar a abertura do parentese
//						if(aux_num == 44) { crs_reservada[i-1] = '\0'; } // caso o final seja uma virgula a �ltima posi��o � retirada
//						
//						vrf = buscar(tabela_simbolos, aux_tipo, crs_reservada); // verifica se a variavel ja existe na lista de simbolos
//						
//						if(vrf == false) { // se n�o existir
//							tabela_simbolos = insere_fim(tabela_simbolos, aux_tipo, crs_reservada, "NULL"); // o valor � inserido na tabela
//						}
					}
				}else{ // fim if (aux_num >= 97) && (aux_num <= 122)
					zerar_vetor_auxiliar(aux_tipo); // zera todo o vetor auxiliar
					imprime_erro(7, linha, crs_reservada); // chama a fun��o de impress�o de erros
				} // fim else/if (aux_num >= 97) && (aux_num <= 122)
			} // fim if (valida_tipo == false) && ((int)crs_reservada[0] == 38)

			i = 0; // zera a vari�vel auxiliar
			zerar_vetor_auxiliar(crs_reservada); // zera todo o vetor auxiliar
		} // fim else de valida��o da palavra
	} // fim if I maior que VAZIO

	i = 0; // zera a vari�vel auxiliar
	zerar_vetor_auxiliar(crs_reservada); // zera todo o vetor auxiliar
} // fim else de ignora��o dos s�mbolos
