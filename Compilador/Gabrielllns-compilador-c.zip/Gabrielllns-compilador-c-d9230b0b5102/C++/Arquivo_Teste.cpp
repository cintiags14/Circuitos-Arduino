main() {
	dec &reajuste(10.2);
	char &salarios(10);
	int &numero, &cont = 5;

	puts();
	gets();
}
