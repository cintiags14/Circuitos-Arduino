package com.unievangelica.progwebback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgWebBackApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProgWebBackApplication.class, args);
    }
}
