package com.unievangelica.progwebback.dominio.colecao;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;


@RunWith(SpringJUnit4ClassRunner.class)
public class ColecaoServiceTest {

    @InjectMocks
    private ColecaoService colecaoService;

    @Mock
    private Colecao colecao;

    @Mock
    private List<Colecao> colecaoList;

    @Mock
    private ColecaoRepository colecaoRepository;

    @Before
    public void init() {
        colecao.setId(1);
        colecao.setNomeColecao("Coleção 1");
        colecaoList.add(colecao);
    }

    /**
     * Testa o método salvar.
     */
    @Test
    public void salvar() {
        BDDMockito.given(colecaoRepository.save(this.colecao)).willReturn(this.colecao);
        Colecao colecao = colecaoService.salvar(this.colecao);
        assertNotNull(colecao);
    }

    /**
     * Testa o método buscarPeloId.
     */
    @Test
    public void buscarPeloId() {
        BDDMockito.given(colecaoRepository.getOne(this.colecao.getId())).willReturn(this.colecao);
        Colecao colecao = colecaoService.buscarPeloId(this.colecao.getId());
        assertNotNull(colecao);
    }

    /**
     * Testa o método findAll.
     */
    @Test
    public void findAll() {
        BDDMockito.given(colecaoRepository.findAll()).willReturn(colecaoList);
        List<Colecao> colecoes = colecaoService.findAll();
        assertTrue(!colecoes.isEmpty());
    }

    /**
     * Testa o método excluir.
     */
    @Test
    public void excluir() {
        BDDMockito.given(colecaoRepository.getOne(this.colecao.getId())).willReturn(this.colecao);
        boolean colecao = colecaoService.excluir(this.colecao.getId());
        assertTrue(colecao);
    }
}
